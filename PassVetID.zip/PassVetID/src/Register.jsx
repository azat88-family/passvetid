export default function Register() {
  return (
    <div className="max-w-4xl mx-auto py-20 text-center">
      <h1 className="text-3xl font-bold mb-4">Criar conta</h1>
      <p className="text-gray-600">
        Escolha o tipo de conta para começar
      </p>
    </div>
  );
}
